// POST - Création d'une proposition par un étudiant (fichier + métadonnées en multipart/form-data).
// Entrée : multipart/form-data (file, title, description, subjectId, typeId, academicYear).
// Sortie : Proposal (contracts/proposals).
// Service : proposalsService.createProposal. Rôle : étudiant validé (ou admin).

import { NextRequest } from "next/server";
import { apiHandler } from "@/server/utils/api-handler";
import { createProposalSchema } from "@/contracts/proposals";
import { proposalsService } from "@/server/services/proposals.service";
import { requireValidatedStudent } from "@/server/auth/guards";
import { ValidationError } from "@/server/errors/http-errors";

export const POST = apiHandler(async (req: NextRequest) => {
  const user = await requireValidatedStudent();

  const formData = await req.formData();
  const file = formData.get("file");

  if (!file || typeof file === "string") {
    throw new ValidationError("Le fichier est requis");
  }

  const rawMeta = {
    title: formData.get("title"),
    description: formData.get("description") || undefined,
    subjectId: formData.get("subjectId"),
    typeId: formData.get("typeId"),
    academicYear: formData.get("academicYear") || undefined,
  };

  const meta = createProposalSchema.parse(rawMeta);

  const arrayBuffer = await file.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  const proposal = await proposalsService.createProposal(
    user.id,
    buffer,
    file.name,
    meta
  );

  return Response.json(proposal, { status: 201 });
});
